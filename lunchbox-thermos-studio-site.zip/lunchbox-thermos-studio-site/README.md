# Lunchbox & Thermos Studios Website

Static GitHub Pages site for Lunchbox & Thermos Studios.

## Before publishing

Replace `support@example.com` in:

- `privacy.html`
- `support.html`

with your real support email.

## GitHub Pages

Upload all files to a public GitHub repository, then enable Pages:

Settings → Pages → Deploy from a branch → main → /root.
